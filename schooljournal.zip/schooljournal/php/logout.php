<?php
session_start();
/*Logout from the website*/
if(session_destroy()) // Destroying All Sessions
{
	header("Location: ../index.php"); // Redirecting To Home Page
}
?>