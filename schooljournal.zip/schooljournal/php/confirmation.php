<?php
/*Tis script is checking for the validity of a conformation email-is the data from the user link  credible?*/
require 'config.php';

// Passkey that got from link 
if (isset($_GET['passkey'])){
	$passkey=$_GET['passkey'];
	$email = $_GET['email'];
}


// Retrieve data from table where row that match this passkey 
$sql="SELECT * FROM register WHERE email = '$email'";
$result=mysqli_query($conn,$sql);

// If successfully queried 
if(($result) && mysqli_num_rows($result)){
// Count how many row has this passkey

$sql_activation = "UPDATE register SET activation = NULL WHERE(email ='$email' AND activation='$passkey')";
$result_activate = mysqli_query($conn,$sql_activation);
$res = mysqli_affected_rows($conn);
echo $res;
if ($result_activate){//if the information in the link is valid send the user to the Login page.
		header("location: ../index.php");
}else {//if there was problem during validation send a message
 	echo '<div>There was a problem with your conformation.Please reload the page, we are sorry for the inconvenience</div>';
 }
}
?>