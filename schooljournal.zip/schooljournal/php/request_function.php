<?php
require 'common.php';
//This script send emails for request subjects feature
if(isset($_POST['submit_request'])){
if(isset($_SESSION['login_user'])){
$username=$_SESSION['login_user'];
}
//If the content is not empty send email containing the information in the textare element of the webpage.
	$content = mysqli_real_escape_string($conn, $_POST["content"]);
	if($content != ""){



				$to='daniel.hinchev@outlook.com';
				$subject = "Request for new subject from $username";
				// Your subject
				$subject = "Request for new subject from $username";

				// From
				$headers =  'From: daniel.hinchev@outlook.com' . "\r\n" .
	    					'Reply-To: daniel.hinchev@outlook.com' . "\r\n" .
	    					'X-Mailer: PHP/' . phpversion();

				// Your message
				$message=$content;

				// send email
				$send = mail($to, $subject, $message, $headers);
				if($send){
					header("location: request.php");
					printf("Your request have been sent succesfully!");
				}	
	}else{
		header("location: request.php");
	}
}
?>