<?php
// Date Base Connection
require 'config.php';

//check if email imail that is about to be inputted in the database have duplicate in the database. If it does send signal to the appropriate script

$registeruseremail = mysqli_real_escape_string($conn, $_POST["email"]);

$sql = "SELECT * FROM `register` WHERE `email` = '$registeruseremail'";

$result = mysqli_query($conn, $sql) or die(mysqli_error());

if(mysqli_num_rows($result)>0){  

    echo 0;

}else{  

    echo 1;  
    
}
?>