<?php
session_start();
require 'config.php';
header('Cache-control: private'); // IE 6 FIX
/*This script deals mainly with language choice and remembering that choice.*/
//if a language has ben selected get its value
if(isSet($_GET['lang']))
{
$lang = $_GET['lang'];

// stire the session and set the cookie
$_SESSION['lang'] = $lang;

setcookie("lang", $lang, time() + (3600 * 24 * 30));
}
else if(isSet($_SESSION['lang']))
{
$lang = $_SESSION['lang'];
}
else if(isSet($_COOKIE['lang']))
{
$lang = $_COOKIE['lang'];
}
else
{
$lang = 'en';
}
//set language rules and tell which language corresponds to which file
//each of the php files below contains the text translation for a different language
switch ($lang) {
  case 'en':
  $lang_file = 'lang.en.php';
  break;

  case 'bg':
  $lang_file = 'lang.bg.php';
  break;

  case 'rus':
  $lang_file = 'lang.rus.php';
  break;
//set a default language
  default:
  $lang_file = 'lang.en.php';

}
//once the language has ben chosen,set it on the page
include_once '../languages/'.$lang_file;
?>