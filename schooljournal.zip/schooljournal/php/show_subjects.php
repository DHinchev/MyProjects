<?php
session_start();
include ('config.php');
if(isset($_SESSION['login_user'])){
$username=$_SESSION['login_user'];
}
//This script is making the custom subjects choice and deletion possible - Choose personal subject feature
if(isset($_POST['subjects_button'])){
if(isset($_POST['custom_sub'])){
//Get every ticked subject and insert that choice in the user_subject table where the users choices will be saved
  foreach( $_POST['custom_sub'] as $get ) {
    if( is_array( $get ) ) {
        foreach( $get as $put ) {
            echo $put;
        }
    } else {
    		 $sqlcheck = "SELECT * FROM user_subjects WHERE user = '$username' AND subjects_parent_id = '$get'";
    		 $selectcheck = mysqli_query($conn,$sqlcheck) or die(mysqli_error($conn));
    		 if(mysqli_num_rows($selectcheck) == 0){
    		 	$sql = "INSERT INTO user_subjects (user,subjects_parent_id) VALUES ('$username','$get')";
		        $select = mysqli_query($conn,$sql) or die(mysqli_error($conn));
		        echo "it works";
    		 }
    	}
	}

}
	 header("Location: main_page.php");
}

//Delete all the custom choices
if(isset($_POST['subjects_button_reset'])){
	$sql="DELETE FROM user_subjects WHERE user = '$username'";
	$select = mysqli_query($conn,$sql) or die(mysqli_error($conn));
	 header("Location: main_page.php");
	}
?>

