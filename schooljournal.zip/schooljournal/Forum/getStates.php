<?php
    include ('../php/config.php');
    global $result;
    //this script is for the search bar functionality.If the input is not empty
    if(!empty($_GET['q']))
    {
        $i=0;
        $q=$_GET['q'];
        //get all the results including subject ,date of creation and author
          $query = "SELECT * FROM categories JOIN subcategories ON `categories`.`cat_id` = `subcategories`.`parent_id` JOIN topics ON `categories`.`cat_id` = `topics`.`category_id`
          WHERE `categories`.`category_title` LIKE '%$q%' OR `subcategories`.`subcategory_title` LIKE '%$q%' OR `topics`.`title` LIKE '%$q%'";
        $result=mysqli_query($conn,$query);
        //get all the results
        while($row=mysqli_fetch_assoc($result))
            {
                  $topic_title=$row['title'];
                  $idtopic=$row['topics_id'];

                  $sub_title=$row['subcategory_title'];
                  $idsub=$row['subcat_id'];

                  $cat_title=$row['category_title'];
                  $idcat=$row['cat_id'];

      //if some of the filtering options was chosen proceed
      if(!empty($_GET['option'])) {
        $searchOp=$_GET['option'];

        //if the chosen filter is to search by category
        if($searchOp=='cat'){
          $outputcat="<a href='/schooljournal/Forum/subcategories.php?cid=".$row['cat_id']."'>".$cat_title."</a><br>";
          echo $outputcat;
      }

        //if the chosen filter is to search by subcategory
        if($searchOp=='sub'){
          $outputsub="<a href='/schooljournal/Forum/topics.php?cid=".$row['cat_id']."&scid=".$row['subcat_id']."'>".$cat_title." ".$sub_title."</a><br>";
          echo $outputsub;
      }

        //if the chosen filter is to search by topic
        if($searchOp=='top'){
          $outputtop="<a href='/schooljournal/Forum/readtopic.php?cid=".$row['cat_id']."&scid=".$row['subcat_id']."&tid=".$row['topics_id']."'>".$cat_title." ".$sub_title." ".$topic_title."</a><br>";
          echo $outputtop;
      }

        //if the chosen filter is to search all the results
        if($searchOp=='all'){
          $outall="<a href='/schooljournal/Forum/readtopic.php?cid=".$row['cat_id']."&scid=".$row['subcat_id']."&tid=".$row['topics_id']."'>".$cat_title." ".$sub_title." ".$topic_title."</a><br>";
          echo $outall;
      }
    }

      else{
          $outputall="<a href='/schooljournal/Forum1/readtopic.php?cid=".$row['cat_id']."&scid=".$row['subcat_id']."&tid=".$row['topics_id']."'>".$cat_title." ".$sub_title." ".$topic_title."</a><br>";
            echo $outputall;
      }
    }
  }
?>
