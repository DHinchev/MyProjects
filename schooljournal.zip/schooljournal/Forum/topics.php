<?php
	include ('content_function.php');
	include_once '../common.php';
	include ('search_engine.php');
	if(isset($_SESSION['login_user'])){
	$username=$_SESSION['login_user'];
	}
?>
<!DOCTYPE html>
	<head><title>School-Journal Forum</title></head>
		<link rel="shortcut icon" type="image/x-icon" href="../media/favicon.ico" />
		<link href="/schooljournal/CSS/forum.css" type="text/css" rel="stylesheet" />
		<link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
		<link href="../assets/bootstrap/css/bootstrap-rtl.min.css" rel="stylesheet" type="text/css"/>
		<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
	<body>
<!--The script displays tpics results -->
<!--HEADER MENU-->
	<div class="container_page">

	<div id="header-container">

	<div id="logout" class="upper-menu"><a href="../php/logout.php"><i class="glyphicon glyphicon-log-out"></i></a></div>
	<div id="dropdown" class="upper-menu"><button id="search" class="fa fa-search fa-2x" onclick="showSearchBar()"></button></div>	
	
	<div id="language" class="upper-menu">
	<h4><?php echo $lang['LANGUAGE_MENU']; ?></h4>
		<div id="select" >
		    <div class="language-select"><a href="topics.php?lang=en"><p>English</p></a></div>
		    <div class="language-select"><a href="topics.php?lang=bg"><p>Български</p></a></div>
		    <div class="language-select"><a href="topics.php?lang=rus"><p>Русский</p></a></div>
		</div>
	</div>
	<div id="welcome"><p><?php echo "Welcome ".$_SESSION['login_user'].""?></p></div>

		<div id="search-bar">
			<div id="search-form-wrapper">
				<form id="search-form" action="topics.php" method="POST">
					<button type="submit" class="fa fa-search fa"></button>
					<input type="search" autocomplete="off" name="search" placeholder="<?php echo $lang['SEARCH']; ?>"  class="search-input"></input>
					<div id="here"></div><br>
					<p>Search by:</p>
					<div class="box"><input  type="radio" name="option" value="cat">Category<br></div>
					<div class="box"><input  type="radio" name="option" value="sub">Subcategory<br></div>
					<div class="box"><input  type="radio" name="option" value="top">Topics<br></div>
					<div class="box"><input  type="radio" name="option" value="all">All<br></div>
				</form> 
			</div>
		</div>
			<div id="main_page" class="upper-menu"><a href="../php/main_page.php"><i class="fa fa-home fa-2x"></i></a></div>
	</div>
<!--END OF HEADER MENU-->
	<div class="header"><h1><a href="/schooljournal/Forum">School-Journal Forum</a></h1></div>

		<div class="content_add">
			<?php 
				if (isset($_SESSION['login_user'])) {
					echo "<form action='/schooljournal/Forum/addnewtopic.php?cid=".$_GET['cid']."&scid=".$_GET['scid']."'
						  method='POST'>
						  <p>Add topic: </p>
						  <input type='text' id='topic' name='topic' size='100' />
						  <p>Content: </p>
						  <textarea id='content' name='content'></textarea><br />
						  <input type='submit' value='add new post' /></form>";
				} else {
					echo "<p>please login first or <a href='/schooljournal/index.php'>click here</a> to register.</p>";
				}
			?>
		</div>
<!-- MAIN CONTENT-->
		<div class="content">
		<h3>Topics</h3>
			<?php disptopics($_GET['cid'], $_GET['scid']); ?>
		</div>
	</div>
	<!-- END OF  MAIN CONTENT-->
<!--SCRIPT-->
	<script src="../Script/forum.js" type="text/javascript"></script>
<!-- END OF SCRIPT-->
</body>
</html>