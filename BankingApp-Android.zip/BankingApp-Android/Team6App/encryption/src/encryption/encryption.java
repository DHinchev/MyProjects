
/*
 * [2022 Team six banking app]
 * 
 * AES encryption & decryption class  
 * Jack Lloyd
 */

package encryption;

// read/write filed
import java.nio.file.Files;
import java.nio.file.Paths;

// java functions needed for AES, etc
import javax.crypto.*;

public class encryption {

		//default thrown all Exceptions let the VM deal with them
		// change to catch and deal locally
    public static void main(String[] args) throws Exception {
    	
    	String toencrypt = "team6 encryption fucntion #1";
        
 
        KeyGenerator KeyGen = KeyGenerator.getInstance( "AES" );
        KeyGen.init( 128 );
        SecretKey SecKey = KeyGen.generateKey();
        Cipher AesCipher = Cipher.getInstance( "AES" );
        
        
        //encrypt mode
        AesCipher.init( Cipher.ENCRYPT_MODE, SecKey );
        byte[] byteCipherText = AesCipher.doFinal( toencrypt.getBytes() );
            
        	/**remove**/ //file output
        	Files.write(Paths.get( /* output file to store the encrypted text */ "encrypted.txt" ), byteCipherText );
        
        	
        //decrypt mode
        byte[] cipherTextfromFile = Files.readAllBytes( Paths.get( /* output file from the encrypt function */ "encrypted.txt" ) );

        AesCipher.init( Cipher.DECRYPT_MODE, SecKey );
        byte[] bytePlainText = AesCipher.doFinal( cipherTextfromFile );
        
        	/**remove**/ //file output
        	Files.write( Paths.get( /* output file to store the original text */ "plaintext.txt" ), bytePlainText );
    }
}