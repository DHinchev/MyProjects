# CSC2022 Team6App

Lloyds android student banking app
