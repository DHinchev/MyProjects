package csc2022.team6.lloydsbanking;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class EditPerson extends Fragment {

    private View v;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.edit_person, container, false);

        // load current data into text fields
        ((EditText) v.findViewById(R.id.first_name_field_edit)).setText( this.getArguments().getString( "f_Name" ));
        ((EditText) v.findViewById(R.id.account_number_field_edit)).setText( Integer.toString( this.getArguments().getInt( "acc" ) ));

        final Button btn = (Button) v.findViewById(R.id.confirm_btn);
        btn.setOnClickListener( new View.OnClickListener() {
            public void onClick( View v ) {
                updateContact();
            }
        });
        return v;
    }

    public EditPerson() {
    }

    public void updateContact(){
        // update database code her
    }
}