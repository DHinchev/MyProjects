package csc2022.team6.lloydsbanking;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Jack on 28/02/2015.
 */
public class AddressBook extends Fragment{

    View rootview;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        rootview = inflater.inflate(R.layout.addressbook_layout, container, false);
        addContacts(getContacts());

        Button guide=new Button(getActivity());
        guide=(Button)rootview.findViewById(R.id.contact_btn);
        guide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment addNew = new AddPerson();
                getFragmentManager().beginTransaction().replace(R.id.container, addNew).commit();
            }
        });

        return rootview;
    }

    public List<Contact> getContacts(){

        // connect to database
        // retrieve contacts for user
        // return .json of contacts

        // parse the .json and add create contact for each entry and add that to the contactList?
        List<Contact> contactList = new ArrayList<Contact>();


        /*** for all contacts in the .json create a contact object, add that to contactList ***/


        //temp testing data
//        contactList.add(new Contact(1, "test", 01521 ));
//        contactList.add(new Contact(2, "test", 408837 ));
//        contactList.add(new Contact(3, "subject", 40837 ));

        return contactList;
    }

    // add contact to table
    public void addContacts( List<Contact> people ){

        // access contact list layout
        LinearLayout contactList_layout = (LinearLayout) rootview.findViewById( R.id.contactList );

        // for all contact object in people, get name and create a textview for that contact
        for ( final Contact c : people) {

            TextView contact = new TextView(getActivity());
            contact.setAllCaps(true);
            contact.setTextSize(30);
            contact.setSingleLine();
            contact.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

            // set to contact class getName method
            contact.setText( c.getName() );

            // click on a contact to bring up summary/history page for that contact
            contact.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Fragment payV = new PayContact();
                    Bundle args = new Bundle();

                    // constructor parameters here using args.put.....
                    args.putString( "name", c.getName() );
                    payV.setArguments( args );

                    getFragmentManager().beginTransaction().replace(R.id.container, payV ).commit();
                }
            });

            // long press contact to bring up edit page
            contact.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {

                    Fragment editP = new EditPerson();
                    Bundle args = new Bundle();

                    // constructor parameters here using args.put.....
                    args.putString("f_Name", c.getName());
                    args.putString("acc", c.getAccNum());

                    editP.setArguments( args );

                    getFragmentManager().beginTransaction().replace(R.id.container, editP ).commit();
                    return true;
                }
            });

            // add new object to view
             contactList_layout.addView(contact);
        }
    }
}
