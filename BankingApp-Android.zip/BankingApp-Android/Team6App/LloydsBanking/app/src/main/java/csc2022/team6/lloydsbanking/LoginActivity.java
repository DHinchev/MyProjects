package csc2022.team6.lloydsbanking;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends ActionBarActivity {

    private User mainUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
        RequestQueue queue = SingletonQueues.getInstance(this.getApplicationContext()).getRequestQueue();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_login, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    // ----------------------------------------------------------------------------------------------------

    public void onloginBTNclick( View v ){

        finish();

        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/login.php";
        final String userID = ((EditText)findViewById( R.id.customerNumber )).getText().toString();
        final String password = ((EditText)findViewById( R.id.customerPassword )).getText().toString();

        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        String result = response;
                        try {
                            JSONObject jsonResponse = new JSONObject(result);
                            JSONArray jsonMainNode = jsonResponse.optJSONArray("Users");
                            JSONObject balanceObj = jsonMainNode.getJSONObject(0);
                            result = balanceObj.optString("boolVal");
                            if(result.compareTo("1") == 0){

                                Intent i = new Intent( LoginActivity.this, NavMenu.class );
                                i.putExtra( "userID", userID );
                                startActivity( i );
                                finish();
                            } else {
                                // not Valid. Some pop-up message?
                            }
                        } catch (JSONException e) {
                            //fill in
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("userID", userID);
                params.put("password", password);
                return params;
            }
        };
        // Access the RequestQueue through your singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
    }

    // take the user to the OFFICIAL lloyds banking website help page
    public void forgottenPassClick( View v ){

        Intent passReset = new Intent( Intent.ACTION_VIEW, Uri.parse( "https://online.lloydsbank.co.uk/personal/a/submitreplaceunlockauthmechanism/customeridentificationdata.jsp" ) );
        startActivity( passReset );
    }

    // clear current textfield text
    public void onFocusNum( View v ){

        EditText custNum = (EditText)findViewById( R.id.customerNumber );
        custNum.setText("");
    }

    // clear current textfield text
    public void onFocusPass( View v ){

        EditText custPass = (EditText)findViewById( R.id.customerPassword );
        custPass.setText("");
    }

    // close the app when back button is pressed on the login screen!
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        startActivity(intent);

        android.os.Process.killProcess( android.os.Process.myPid() );
    }
}
