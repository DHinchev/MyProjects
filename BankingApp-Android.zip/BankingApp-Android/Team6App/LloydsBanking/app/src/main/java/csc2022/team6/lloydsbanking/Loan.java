package csc2022.team6.lloydsbanking;


import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by mladj_000 on 16/04/2015.
 */
public class Loan {

    private int LID;
    private String source;
    private String dest;
    private double amount;
    private String date;
    private String message;

    public Loan(String source, String dest, double amount, String message){
        this.source = source;
        this.dest = dest;
        this.amount = amount;
        this.message = message;

        Calendar c = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        date = format.format(c.getTime());


        generateID(new VolleyCallback() {
            @Override
            public void onSuccess(String result) {
                LID = Integer.parseInt(result) + 1;
                addToDatabase();
            }
        });
    }

    public Loan(int LID, String source, String dest, double amount, String date, String message){
        this.LID = LID;
        this.source = source;
        this.dest = dest;
        this.amount = amount;
        this.date = date;
        this.message = message;
    }

    private void generateID(final VolleyCallback volleyCallback){
        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/getMaxLoanID.php";

        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        String result = response;
                        try {
                            JSONObject jsonResponse = new JSONObject(result);
                            JSONArray jsonMainNode = jsonResponse.optJSONArray("Loans");
                            JSONObject resultsObj = jsonMainNode.getJSONObject(0);
                            result = resultsObj.optString("loanID");
                        } catch (JSONException e) {
                            //fill in
                        }
                        volleyCallback.onSuccess(result);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                return params;
            }
        };
        // Access the RequestQueue through your singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
    }

    private void addToDatabase(){
        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/CreateLoan.php";

        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Nothing to do on response
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("LID", Integer.toString(getLID()));
                params.put("source", getSource());
                params.put("destination", getSource());
                params.put("amount", getSource());
                params.put("date", getSource());
                params.put("message", getSource());
                return params;
            }
        };
        // Access the RequestQueue through your singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
    }

    public int getLID(){
        return LID;
    }

    public String getMessage() {
        return message;
    }

    public String getSource() {
        return source;
    }

    public String getDest() {
        return dest;
    }

    public double getAmount() {
        return amount;
    }

    public String getDate() {
        return date;
    }
}

