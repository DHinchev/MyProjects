package csc2022.team6.lloydsbanking;

import java.util.ArrayList;

/**
 * Created by Tonham on 16/04/2015.
 */
public interface AccountsCallback {
    void onSuccess(ArrayList<StudentAccount> accountList);
}
