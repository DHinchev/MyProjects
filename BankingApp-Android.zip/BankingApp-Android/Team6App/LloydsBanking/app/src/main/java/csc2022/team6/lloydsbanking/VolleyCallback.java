package csc2022.team6.lloydsbanking;

/**
 * Created by mladj_000 on 13/04/2015.
 */
public interface VolleyCallback {
    void onSuccess(String result);
}
