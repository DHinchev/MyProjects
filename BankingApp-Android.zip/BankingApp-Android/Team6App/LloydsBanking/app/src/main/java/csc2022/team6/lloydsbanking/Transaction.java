package csc2022.team6.lloydsbanking;

/*
* 	Author: Brixton Hamilton
*	Date: February 2015
*
*	Class Transaction
*		Models a transaction between bank accounts to allow accessing of database variables
*
*	Constructors:
*	Provides two constructors, one for transferring a database entry to an object, which
*		populates the fields with the database values from the parameter transaction ID,
*		and one for creating a new transaction, which takes the field variables as parameters
*		and generates a new transaction ID.
*
*	Methods:
*	Provides get methods for the class fields along with
*	private String generateID()
*		Generates and returns a transaction ID for the transaction
*	public void addToDatabase()
*		Adds the transaction to the database, first by sending a volley to retrieve the highest current Transaction ID and giving the value
*	     to the SetTID() method to extract, calculate and set the global TID. Once the TID has been returned, we create and send a volley to store
*	     the transaction in the database, creating a Calendar object to set the right date of the transaction.
*	public boolean SetTID()
*       Extracts a Transaction ID value from a given Json encoded string returned from a Volley, increments the value and stores it as the TID
*       for this object. However, if the Transaction already has a TID, then it will not give it a new TID.
*   public checkDest()
*       Check the destination accountNumber of this transaction, and use a VolleyCallback object to return a value StudentAccount which will have
*       called this method. If the destination account is not valid account, a Json error will be thrown when interpreting the volley response.
*       This error is caught, and the VolleyCallback object is called anyway and the value "false" is returned instead. This will suffice in
*       signalling that the destination account number was unusable, as the "false" value be read appropraitely by the StudentAccount class.
*	public String toString()
*		Returns a formatted string summary of the transaction
*/

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public final class Transaction
{

    private final String source; // The payee accountNumber
    private final String destination; // The accountNumber to be paid
    private final double amount; // The amount of money to be transferred
    private int TID = -1; // The transaction ID of this transaction. -1 signifies a null value.
    private String description; // The description to be saved with this transaction
    private String date; // The data this transaction was sent
    private String tag;

    public Transaction(int TID, String src, String dst, double amount, String date, String description)
    {
        this.TID = TID;
        this.source = src;
        this.destination = dst;
        this.amount = amount;
        this.description = description;
        this.date = date;
    }

    public Transaction(String src, String dst, double amount, String description)
    {
        this.source = src;
        this.destination = dst;
        this.amount = amount;
        this.description = description;
    }

    public String toString()
    {
        return new String("From: " + source + ", To: " + destination + ", Amount: " + amount + ", Description: " + description );
    }

    // SetTID will take the Volley response value returned in addToDatabase, which should hold the transaction number for this transaction
    // in Json form. This method will extract the TTD and set it to the global value.
    private boolean setTID(String stringTID)
    {
        if(TID != -1){
            return true;
            /* -1 represents a null value, if the TID has already been set then we should not override its value. The TID cannot be set to -1
            * -Ivan 03.05.2015 */
        }
        int result = 0;
        try {
            // Extract the value from Json format
            JSONObject jsonResponse = new JSONObject(stringTID);
            JSONArray jsonMainNode = jsonResponse.optJSONArray("Transactions");
            JSONObject maxID = jsonMainNode.getJSONObject(0);
            result = Integer.parseInt(maxID.optString("id"));
        } catch (JSONException e) {
            //fill in
        }
        if(result == -1){
            return false;
            /* TID should not be set to -1 as this is supposed to be a designated "null" value. This is an unlikely situation and indicates
            an error case in the database or php. - Ivan 03.05.2015 */
        }
        TID = result + 1; // Increment TID of latest transaction in database to create new TID for this transaction
        System.out.println("Set the Transaction ID to " + result + 1);
        return true;
    }

    public void addToDatabase()
    {
        /* First we will generate the Transaction ID by sending a Volley. */
        final String urlMaxTID = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/MaxTransactionID.php";

        /* This StringRequest will retrieve the TID to use for the transaction. The Volley used to add the Transaction to the database is dependent
        * on this volley returning a TID to use. This means that for the Volley operation to add the transaction to the database, its url
        * and StringRequest elements must be created after stringRequestMaxTID has returned the appropriate TID (we ensure they are created after
         * the stringRequestMaxTID has responded by instantiating them in the EventListener). */
        StringRequest stringRequestMaxTID = new StringRequest
                (Request.Method.POST, urlMaxTID, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        String maxTransactionResult = response; // Store the response from the Volley
                        System.out.println(" **transaction volley recieved** ");

                        /* Next, calling setTID() will convert maxTID Volley response into a usable value and set the TID field for transaction.
                         * If the method returns false, there has been an error with the value returned by the volley. If the TID value is good,
                         * or this transaction already had a value, then it the transaction is ready to be stored in the database.
                         * It is important that the URL String for storing this transaction in the database is instansiated in this EventListrner
                          * of the first volley because the new volley is dependent on the first volley returning a TID value to be stored.*/
                        if(setTID(maxTransactionResult)){
                            Calendar c = Calendar.getInstance();
                            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                            final String date = format.format(c.getTime());

                            /* Create the url for the store transaction Volley. The TID has been returned from the MaxTID Volley */
                            final String urlStoreT = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/CreateTransaction.php";
                            System.out.println("  -- The url was: " + urlStoreT + "--  ");

                            /* Create the StringRequest that will store the transaction */
                            StringRequest stringRequestStoreT = new StringRequest
                                    (Request.Method.POST, urlStoreT, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {
                                            // Updating the database only needs to call the url, no post-action required
                                            System.out.println("  --Ad to databse Volley Sent--  ");
                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            // TODO Auto-generated method stub
                                        }
                                    }){
                                @Override
                                protected Map<String, String> getParams()
                                {
                                    Map<String, String>  params = new HashMap<String, String>();
                                    params.put("transactionID", Integer.toString(getTID()));
                                    params.put("sender", getSource());
                                    params.put("recipient", getDest());
                                    params.put("amount", Double.toString(getAmount()));
                                    params.put("date", date);
                                    params.put("description", "MAKEME");
                                    return params;
                                }
                            };
                            // Access the RequestQueue through your singleton class.
                            SingletonQueues.getInstance().addToRequestQueue(stringRequestStoreT);
                        } else {
                            /*Error case, we tried to set the TID to -1, this is not allowed. The transaction record has not been stored in the
                            * database. Since the transaction has already occurred by Volley in Student Account, this transaction could possibly
                            * be sent with -1 TID to indicate that the transaction happened but a TID could not be assigned.*/
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                return params;
            }
        };
        // Access the RequestQueue through your singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequestMaxTID);
    }


    public String getSource()
    {
        return new String(source);
    }
    public String getDest()
    {
        return new String(destination);
    }
    public double getAmount()
    {
        return amount;
    }
    public String getDate() { return date; }
    public int getTID()
    {
        return TID;
    }
    public String getTag(){ return tag; }
    public String getDescription(){ return description; }

    public void updateTag(final String newTag){
        String addTag = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/setTag.php";

        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, addTag, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("tag", newTag);
                params.put("TID", Integer.toString(TID));
                return params;
            }
        };
        this.tag = newTag;
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
    }

    public void removeTag(){
        String removeTag = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/removeTag.php";

        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, removeTag, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("TID", Integer.toString(TID));
                return params;
            }
        };
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
        this.tag = null;
    }



    /* This method will send a volley to check that the destination accountNumber is a real account. the VolleyCallback parameter is used
    * to return the string value back to the class that called this method. Normally, a StudentAccount will be calling checkDest() before
    * starting a transaction. If the accountNumber is indeed incorrect, then the server will return a null value in its
    * Json response, however the Json unwrapping (in the EventListener of this Volley) will create an error when trying to handle a null
    * value. The Json error will be caught in the catch block, and the volleyCallback object will be used to return the string "false". */
    public void checkDest(final VolleyCallback volleyCallback){
        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/ValidReceiver.php";

        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //No action required on response
                        String result;
                        try {
                            // extract the value from its Json formatting
                            JSONObject jsonResponse = new JSONObject(response);
                            JSONArray jsonMainNode = jsonResponse.optJSONArray("Accounts");
                            JSONObject accountNumber = jsonMainNode.getJSONObject(0);
                            result = accountNumber.optString("boolVal");
                            volleyCallback.onSuccess(result);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("accountNumber", getDest());
                return params;
            }
        };
        // Access the RequestQueue through the singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
    }



}

