package csc2022.team6.lloydsbanking;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.LruCache;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;

/**
 * Created by mladj_000 on 23/03/2015.
 */
public class SingletonQueues {
    private static SingletonQueues mInstance;
    private RequestQueue mRequestQueue;
    private ImageLoader mImageLoader;
    private static Context mCtx;

    private SingletonQueues(Context context) {
        mCtx = context;
        mRequestQueue = getRequestQueue();

        mImageLoader = new ImageLoader(mRequestQueue,
                new ImageLoader.ImageCache() {
                    private final LruCache<String, Bitmap>
                            cache = new LruCache<String, Bitmap>(20);

                    @Override
                    public Bitmap getBitmap(String url) {
                        return cache.get(url);
                    }

                    @Override
                    public void putBitmap(String url, Bitmap bitmap) {
                        cache.put(url, bitmap);
                    }
                });
    }

    public static synchronized SingletonQueues getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new SingletonQueues(context);
        }
        return mInstance;
    }

    /**
     * This will return instance, if a new one needs to be instantiated it will be set to a new SingletonQueues object with the Application Context.
     * <p>
     * This was created so we do not need to pass the Application Context to classes when they use Volley, like Transaction. If the SingletonQueue
     * was created in MainActivity and passed getApplicationContext as a parameter, then the application context is stored and we can use this copy
     * of the Application Context. This way, if getInstance() is being called by a class that would normally pass it the Application context, it
     * doesn't need to, and we do not need to pass a context to those classes (like Transaction). -Ivan 29/04/2015</p>
     * */
    public static synchronized SingletonQueues getInstance() {
        if (mInstance == null) {
            mInstance = new SingletonQueues(mCtx);
        }
        return mInstance;
    }

    public RequestQueue getRequestQueue() {
        if (mRequestQueue == null) {
            // getApplicationContext() is key, it keeps you from leaking the
            // Activity or BroadcastReceiver if someone passes one in.
            mRequestQueue = Volley.newRequestQueue(mCtx.getApplicationContext());
        }
        return mRequestQueue;
    }

    public <T> void addToRequestQueue(Request<T> req) {
        getRequestQueue().add(req);
    }

    public ImageLoader getImageLoader() {
        return mImageLoader;
    }
}
