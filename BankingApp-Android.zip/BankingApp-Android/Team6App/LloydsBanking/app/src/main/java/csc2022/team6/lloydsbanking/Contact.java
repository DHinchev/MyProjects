package csc2022.team6.lloydsbanking;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by mladj_000 on 15/04/2015.
 */
public class Contact {

    private final String contactAccountNumber;
    private final String hostUserID;
    private final String date;
    private final String name;
    private final String description;

    public Contact(String hostUserID, String name, String contactAccountNumber, String date, String description)
    {
        this.hostUserID = hostUserID;
        this.name = name;
        this.contactAccountNumber = contactAccountNumber;
        this.date = date;
        this.description = description;
    }

    public Contact(String hostUserID, String name, String contactAccountNumber, String description)
    {
        this.hostUserID = hostUserID;
        this.name = name;
        this.contactAccountNumber = contactAccountNumber;
        this.description = description;
        Calendar c = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        this.date = format.format(c.getTime());
    }

    public String toString()
    {
        return new String(name + ", " + contactAccountNumber + ", " + date);
    }

    public void addToDatabase()
    {
        final String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/CreateContact.php";

                            /* Create the StringRequest that will store the contact */
        StringRequest stringRequestStoreT = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Updating the database only needs to call the url, no post-action required
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("contactName", name);
                params.put("hostUserID", hostUserID);
                params.put("guestAccountNumber", contactAccountNumber);
                params.put("date", date);
                params.put("description", description);
                return params;
            }
        };
        // Access the RequestQueue through your singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequestStoreT);
    }

    public void removeFromDatabase()
    {
        final String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/DeleteContact.php";

                            /* Create the StringRequest that will store the contact */
        StringRequest stringRequestStoreT = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Updating the database only needs to call the url, no post-action required
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("hostUserID", hostUserID);
                params.put("guestAccountNumber", contactAccountNumber);
                return params;
            }
        };
        // Access the RequestQueue through your singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequestStoreT);
    }

    public void checkDest(final VolleyCallback volleyCallback){
        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/ValidReceiver.php";

        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        String result;
                        try {
                            // extract the value from its Json formatting
                            JSONObject jsonResponse = new JSONObject(response);
                            JSONArray jsonMainNode = jsonResponse.optJSONArray("Accounts");
                            JSONObject accountNumber = jsonMainNode.getJSONObject(0);
                            result = accountNumber.optString("accountNumber");
                            volleyCallback.onSuccess(result);
                        } catch (JSONException e) {
                            e.printStackTrace();
                            volleyCallback.onSuccess("false");
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("accountNumber", contactAccountNumber);
                return params;
            }
        };
        // Access the RequestQueue through the singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
    }
    public String getAccNum()
    {
        return contactAccountNumber;
    }
    public String getName(){return  new String(name);}
}
