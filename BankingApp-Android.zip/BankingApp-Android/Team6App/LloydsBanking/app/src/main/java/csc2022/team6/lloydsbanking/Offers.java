package csc2022.team6.lloydsbanking;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by Jack on 28/02/2015.
 */
public class Offers extends Fragment {


    View rootview;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        System.out.println("creating view");
        rootview = inflater.inflate( R.layout.offers_layout, container, false );
        getAllOffers(new OffersCallback(){
            @Override
            public void onSuccess(final ArrayList<Offer> offers)
            {
                loadOffers(offers);
            }
        });
        return rootview;
    }

    public Offers(){
    }

    private void getAllOffers(final OffersCallback volleyCallback){

        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/GetOffers.php";
        List<Offer> allOffers = new ArrayList<Offer>();

        StringRequest stringRequest = new StringRequest
                (Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        ArrayList<Offer> allOffers = new ArrayList<Offer>();

                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            JSONArray jsonMainNode = jsonResponse.optJSONArray("Offers");
                            for(int i = 0; i<jsonMainNode.length(); i++)
                            {
                                JSONObject jsonRow = jsonMainNode.getJSONObject(i);
                                int offerID = Integer.parseInt(jsonRow.optString("offerID"));
                                String name = jsonRow.optString("offerName");
                                String description = jsonRow.optString("offerDescription");
                                String offerMediaURL = jsonRow.optString("offerMediaURL");
                                Offer next = new Offer(offerID, name, description, offerMediaURL);
                                allOffers.add(next);

                                System.out.println("Added all offers to table, number = " + jsonMainNode.length());
                            }
                        } catch (JSONException e) {
                            //fill in
                        }
                        volleyCallback.onSuccess(allOffers);
                        System.out.println("called volleycallback");

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }){
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                return params;
            }
        };
        // Access the RequestQueue through the singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
    }

    public void loadOffers(  List<Offer> offer_list  ) {

        TableLayout offerTable = (TableLayout) rootview.findViewById(R.id.offer_table);
        System.out.println("offers loaded: this many " + offer_list.size());
        for ( final Offer o : offer_list) {
            TableRow offer = new TableRow(getActivity());

            ImageView icon = new ImageView(getActivity());
            setIconFromURL(icon, o.getOfferMediaURL());

            TextView desc = new TextView(getActivity());
            desc.setText(o.getDescription());

            offer.addView(icon);
            offer.addView(desc);

            offer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Fragment map = new Guide();
                    Bundle args = new Bundle();

                    // constructor parameters here using args.put.....
                    args.putString( "searchValue", "offer business" );
                    map.setArguments( args );

                    getFragmentManager().beginTransaction().replace(R.id.container, map ).commit();
                }
            });

            offerTable.addView(offer);
        }
    }

    public void setIconFromURL( final ImageView icon, String url ) {
        ImageRequest stringRequest = new ImageRequest
                (url, new Response.Listener<Bitmap>() {
                    @Override
                    public void onResponse(Bitmap bitMap) {
                        System.out.println( "volley called" );
                        icon.setImageBitmap(Bitmap.createScaledBitmap( bitMap, 150, 150, false )) ;
                    }
                }, 0, 0, null,
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // icon.setImageResource(R.drawable.image_load_error);
                            }
                        });
        SingletonQueues.getInstance(getActivity().getApplicationContext()).addToRequestQueue(stringRequest);
    }

    private void hi(){
        /*try {
            JSONObject jsonResponse = new JSONObject(response);
            JSONArray jsonMainNode = jsonResponse.optJSONArray("Transaction");
            for(int i = 0; i<jsonMainNode.length(); i++)
            {
                JSONObject jsonRow = jsonMainNode.getJSONObject(i);
                int id = Integer.parseInt(jsonRow.optString("transactionID"));
                String src = jsonRow.optString("sender");
                String dst = jsonRow.optString("recipient");
                Double amount = Double.parseDouble(jsonRow.optString("amount"));
                String date = jsonRow.optString("date");
                String desc = jsonRow.optString("description");
                Transaction t = new Transaction(id, src, dst, amount, date, desc);
                transactions.add(t);
            }
                            *//*JSONObject balanceObj = jsonMainNode.getJSONObject(0);
                            result = balanceObj.optString("balance");
                            this.balance = Double.parseDouble(result);*//*
        } catch (JSONException e) {
            //fill in
        }*/
    }
}
