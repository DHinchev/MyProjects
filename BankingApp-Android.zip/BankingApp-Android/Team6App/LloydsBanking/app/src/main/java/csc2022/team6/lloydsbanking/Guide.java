package csc2022.team6.lloydsbanking;  // change to your own package

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMapOptions;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * A fragment that launches other parts of the demo application.
 */
public class Guide extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.guide_layout, container,false);


        return v;
    }

    class HoldFragmentPlace extends FragmentActivity implements OnMapReadyCallback {

        GoogleMap map;
        public GoogleMapOptions options = new GoogleMapOptions();

        public HoldFragmentPlace() {

        }

        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View v = inflater.inflate(R.layout.guide_layout, container,
                    false);

            MapFragment mapFragment = (MapFragment) getFragmentManager()
                    .findFragmentById(R.id.mapView);
            mapFragment.getMapAsync(this);
            map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
            return v;
        }

        public void onMapReady(GoogleMap map) {
            map.addMarker(new MarkerOptions()
                    .position(new LatLng(51.5072, 0.1275))
                    .title("London"));
        }


    }
}