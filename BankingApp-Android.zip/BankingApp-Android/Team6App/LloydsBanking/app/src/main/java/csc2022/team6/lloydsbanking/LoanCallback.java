package csc2022.team6.lloydsbanking;

/**
 * Created by Tonham on 16/04/2015.
 */

import java.util.ArrayList;

public interface LoanCallback
{
    void onSuccess(ArrayList<Loan> loanList);
}
