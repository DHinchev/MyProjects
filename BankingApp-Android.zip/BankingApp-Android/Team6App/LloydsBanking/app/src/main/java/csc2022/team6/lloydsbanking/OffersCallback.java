package csc2022.team6.lloydsbanking;

import java.util.ArrayList;

/**
 * Created by Tonham on 16/04/2015.
 */
public interface OffersCallback {
    void onSuccess(ArrayList<Offer> offerList);
}
