package csc2022.team6.lloydsbanking;

/*
* 	Author: Brixton Hamilton
*	Date: February 2015
*
*	Class StudentAccount implements Account
*		Models a Student bank account, implementing the standard account methods.
*
*	Constructors:
*		Provides a single constructor with the parameter of an account number,
*		that imports the database entry of that account number.
*
*	Methods:
*	Implements all the Account interface methods
*/

import android.content.Context;
import android.os.AsyncTask;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;


public class StudentAccount implements Account {
    private String UID = "";
    private final String number;
    private String getParentResult;
    private double interest;
    private double overdraft;
    private double balance;

    public StudentAccount(String number) {
        this.number = number;
    }

    public StudentAccount(String number, String UID) {
        //FOR TESTING ONLY PLEASE REMOVE
        this.number = number;
        this.UID = UID;
    }

    public void makeTransaction(final Transaction t) {

        System.out.print("Request queue in Student Account created for makeTransaction");

        t.checkDest(new VolleyCallback(){
            @Override
            public void onSuccess(String result){
                if(result.compareTo("1") == 0){
                    System.out.print("--- The destination account WAS valid and the transaction moved forward ---");
                    updateBalance(new VolleyCallback(){
                        @Override
                        public void onSuccess(String result){
                            if(balance + overdraft >= t.getAmount()){
                                clearTransaction(t);
                                System.out.println("+++ Transaction went through +++");
                            } else {
                                System.out.println("+++ Transaction could not be funded +++");
                            }
                        }
                    });
                } else if (result.compareTo("0") == 0) {
                    System.out.print("--- The destination account was NOT valid and the transaction did not clear ---");
                }
            }
        });


    }

    public void clearTransaction(Transaction t){
        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/Transaction.php";
        final String tSource = t.getSource();
        final String tDest = t.getDest();
        final double tAmount = t.getAmount();
        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //No action required on response
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("userID", tSource);
                params.put("receiverID", tDest);
                params.put("amount", Double.toString(tAmount));
                return params;
            }
        };
        // Access the RequestQueue through the singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
        // Add the transaction to the database.
        t.addToDatabase();
    }

    public String toString() {
        return String.format("%-12s,%-10s, %2.2f", number, "student", balance);
    }

    public void getTransactions(final TransactionsCallback volleyCallback)
    {
        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/GetAllTransactions.php";
        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        ArrayList<Transaction> transactions = new ArrayList<Transaction>();

                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            JSONArray jsonMainNode = jsonResponse.optJSONArray("Transaction");
                            for(int i = 0; i<jsonMainNode.length(); i++)
                            {
                                JSONObject jsonRow = jsonMainNode.getJSONObject(i);
                                int id = Integer.parseInt(jsonRow.optString("transactionID"));
                                String src = jsonRow.optString("sender");
                                String dst = jsonRow.optString("recipient");
                                Double amount = Double.parseDouble(jsonRow.optString("amount"));
                                String date = jsonRow.optString("date");
                                String desc = jsonRow.optString("description");
                                Transaction t = new Transaction(id, src, dst, amount, date, desc);
                                transactions.add(t);
                            }
                            /*JSONObject balanceObj = jsonMainNode.getJSONObject(0);
                            result = balanceObj.optString("balance");
                            this.balance = Double.parseDouble(result);*/
                        } catch (JSONException e) {
                            //fill in
                        }
                        volleyCallback.onSuccess(transactions);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("number", getNumber());
                return params;
            }
        };
        // Access the RequestQueue through the singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
        // Add the transaction to the database.
    }

    public double getBalance() {
        return balance; // Subject to change, query database
    }

    public double getAPR() {
        return interest; // Subject to change, query database
    }

    public double getOverdraft() {
        return overdraft; // Subject to change, query database
    }

    public String getNumber() {
        return new String(number);
    }

    public String getOwnerID() {
        return new String(UID);
    }

    @Override
    public double updateBalance(final VolleyCallback volleyCallback) {
        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/GetBalance.php";

        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        String retrievedBalance = response;
                        setBalance(retrievedBalance);
                        volleyCallback.onSuccess(retrievedBalance);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("accountNumber", getNumber());
                return params;
            }
        };
        // Access the RequestQueue through your singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
        return 0;
    }

    private void setBalance(String balance){
        String result;
        try {
            JSONObject jsonResponse = new JSONObject(balance);
            JSONArray jsonMainNode = jsonResponse.optJSONArray("Accounts");
            JSONObject balanceObj = jsonMainNode.getJSONObject(0);
            result = balanceObj.optString("balance");
            this.balance = Double.parseDouble(result);
        } catch (JSONException e) {
            //fill in
        }
    }

    public void fetchFields(final VolleyCallback volleyCallback){
        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/getAccountFields.php";
        System.out.println("Fetching fields");
        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        String result = response;
                        System.out.println("Response is: " + result);
                        String retrievedInterest;
                        String retrievedOverdraft;
                        System.out.println("Setting fields");
                        try {
                            JSONObject jsonResponse = new JSONObject(result);
                            JSONArray jsonMainNode = jsonResponse.optJSONArray("Accounts");
                            JSONObject resultsObj = jsonMainNode.getJSONObject(0);
                            retrievedInterest = resultsObj.optString("interest");
                            System.out.println("optstring: " + resultsObj.optString("overdraft"));
                            retrievedOverdraft = resultsObj.optString("overdraft");
                            System.out.println("retrieved: " + retrievedOverdraft);
                            UID = resultsObj.optString("ownerID");
                            interest = Double.parseDouble(retrievedInterest);
                            overdraft = Double.parseDouble(retrievedOverdraft);
                            System.out.println("od: " + overdraft);
                            volleyCallback.onSuccess("Success");
                        } catch (JSONException e) {
                            //fill in
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("accountNumber", getNumber());
                return params;
            }
        };
        // Access the RequestQueue through your singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
    }


    public void getLoans(final LoanCallback volleyCallback){
        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/GetAllLoans.php";

        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        String result = response;
                        ArrayList<Loan> allLoans = new ArrayList<Loan>();
                        try {
                            JSONObject jsonResponse = new JSONObject(result);
                            JSONArray jsonMainNode = jsonResponse.optJSONArray("Loans");
                            for(int i = 0; i<jsonMainNode.length(); i++) {
                                JSONObject jsonRow = jsonMainNode.getJSONObject(i);
                                int LID = Integer.parseInt(jsonRow.optString("LID"));
                                String source = jsonRow.optString("source");
                                String dest = jsonRow.optString("destination");
                                double amount = Double.parseDouble(jsonRow.optString("amount"));
                                String date = jsonRow.optString("date");
                                String message = jsonRow.optString("message");
                                Loan newLoan = new Loan(LID, source, dest, amount, date, message);
                                allLoans.add(newLoan);
                            }
                        } catch (JSONException e) {
                            //fill in
                        }
                        volleyCallback.onSuccess(allLoans);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("accountNumber", getNumber());
                return params;
            }
        };
        // Access the RequestQueue through your singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
    }

}