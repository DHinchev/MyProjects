package csc2022.team6.lloydsbanking;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/*
* 	Author: Brixton Hamilton
*	Date: February 2015
*
*	Class User
*		Models a bank account user, with fields for the currently selected account,
*		user ID, and name.
*
*	Constructors:
*	Provides a single constructor, which creates a user object from a database entry using
*		the user ID as a parameter.
*
*	Methods:
*	Provides get methods for the class fields along with
*	private void openAccount(String type)
*		opens a new account for the user with the specified type
*	private void switchAccount(Account a)
*		switches the currently active account for the user to the one in the parameter.
*/

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

public class User
{
    private final String UID;
    private List<StudentAccount> accountList;
    private String name;

    public User(String UID)
    {
        this.UID = UID;
        fetchName(UID);
        fetchAccounts(new AccountsCallback(){
            @Override
            public void onSuccess(ArrayList<StudentAccount> accounts){
                accountList = accounts;
            }
        });
    }

    private void fetchName(String UID){
        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/OwnerName.php";

        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        String result = response;
                        setName(result);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("UID", getID());

                return params;
            }
        };
        // Access the RequestQueue through your singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
    }

    private void setName(String result){
        try {
            JSONObject jsonResponse = new JSONObject(result);
            JSONArray jsonMainNode = jsonResponse.optJSONArray("Users");
            JSONObject accountNumber = jsonMainNode.getJSONObject(0);
            name = accountNumber.optString("name");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void fetchAccounts(final AccountsCallback volleyCallback){
        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/GetAccounts.php";
        System.out.println("yyyyyyyy");
        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        ArrayList<StudentAccount> accounts = new ArrayList<StudentAccount>();
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            JSONArray jsonMainNode = jsonResponse.optJSONArray("Accounts");
                            for(int i = 0; i<jsonMainNode.length(); i++)
                            {
                                System.out.println("In loop size : " + accounts.size());
                                JSONObject jsonRow = jsonMainNode.getJSONObject(i);
                                String accountNumber = jsonRow.optString("accountNumber");
                                final StudentAccount s = new StudentAccount(accountNumber);
                                accounts.add(s);
                            }
                        } catch (JSONException e) {
                            //fill in
                        }
                        System.out.println("onSuccess call size: " + accounts.size());
                        volleyCallback.onSuccess(accounts);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("UID", getID());
                return params;
            }
        };
        // Access the RequestQueue through your singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
    }

    public void getContacts(final ContactsCallback volleyCallback){
        String url = "http://homepages.cs.ncl.ac.uk/2014-15/csc2022_team6/GetContacts.php";

        StringRequest stringRequest = new StringRequest
                (Request.Method.POST, url, new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        ArrayList<Contact> contacts = new ArrayList<Contact>();
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            JSONArray jsonMainNode = jsonResponse.optJSONArray("Contacts");
                            for(int i = 0; i<jsonMainNode.length(); i++)
                            {
                                JSONObject jsonRow = jsonMainNode.getJSONObject(i);
                                String contactName = jsonRow.optString("contactName");
                                String accountNumber = jsonRow.optString("guestAccNum");
                                String date = jsonRow.optString("date");
                                Contact c = new Contact(UID, contactName, accountNumber, date, ""); //FIX ME!!!"!"!"
                                contacts.add(c);
                            }
                        } catch (JSONException e) {
                            //fill in
                        }
                        volleyCallback.onSuccess(contacts);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                    }
                }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("hostUserID", getID());
                return params;
            }
        };
        // Access the RequestQueue through your singleton class.
        SingletonQueues.getInstance().addToRequestQueue(stringRequest);
    }

    public void addContact(final Contact c)
    {

        c.checkDest(new VolleyCallback(){
            @Override
            public void onSuccess(String result){
                if(result.compareTo(c.getAccNum()) == 0){
                    System.out.print("--- The account number WAS valid and the contact moved forward ---");
                    c.addToDatabase();
                } else {
                    System.out.print("--- The account number entered was NOT valid and the contact was NOT added ---");
                }
            }
        });

    }

    public void editContact(final Contact old, final Contact young)
    {

        young.checkDest(new VolleyCallback(){
            @Override
            public void onSuccess(String result){
                if(result.compareTo(young.getAccNum()) == 0){
                    System.out.print("--- The account number WAS valid and the contact moved forward ---");
                    old.removeFromDatabase();
                    young.addToDatabase();
                } else {
                    System.out.print("--- The account number entered was NOT valid and the contact was NOT added ---");
                }
            }
        });

    }


    public String getName()
    {
        return new String(name);
    }
    public String getID()
    {
        return new String(UID);
    }

}
