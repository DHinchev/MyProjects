package csc2022.team6.lloydsbanking;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

/**
 * Created by Howk on 10.4.2015 г..
 */
public class AddPerson extends Fragment{

    View rootView;

    public View onCreateView(LayoutInflater inflater,ViewGroup container,Bundle saveInstanceState) {
        rootView = inflater.inflate(R.layout.add_person, container, false);

        buttonHandle();
        return rootView;
    }

    public void buttonHandle(){

        Button confirmation = (Button) rootView.findViewById( R.id.add_button );
        confirmation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // add person to db
            }
        });
    }
}

