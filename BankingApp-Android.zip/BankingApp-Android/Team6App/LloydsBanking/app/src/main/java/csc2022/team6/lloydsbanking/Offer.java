package csc2022.team6.lloydsbanking;

/**
 * Created by mladj_000 on 16/04/2015.
 */
public class Offer {

    private int offerID;
    private String name;
    private String description;
    private String offerMediaURL;

    public Offer(int offerID, String name, String description, String offerMediaURL){
        this.offerID = offerID;
        this.name = name;
        this.description = description;
        this.offerMediaURL = offerMediaURL;
    }

    public int getOfferID() {
        return offerID;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getOfferMediaURL() {
        return offerMediaURL;
    }
}
