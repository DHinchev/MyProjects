package csc2022.team6.lloydsbanking;
/*
* 	Author: Brixton Hamilton
*	Date: February 2015
*
*	Interface Account
*		Models a bank account to store information and provide account manipulation functions
*
*	Methods:
*	String getOwnerID()
*		Returns the userID of the User to which the account belongs
*	double getBalance()
*		Queries the database and  returns the current balance of the account
*	double getAPR()
*		Queries database and returns the annual percentage rate of interest
*	double getOverdraft()
*		Queries the database and returns the maximum available overdraft for the account
*	String getNumber()
*		Returns the associated account number
*	void makeTransaction(Transaction t) throws InsufficientFundsException
*		Creates a transaction with the template of the Transaction object parameter
*	String toString()
*		Returns a string summary of the account
*/

public interface Account
{
    public String getOwnerID();
    public double updateBalance(VolleyCallback volleyCallback);
    public double getAPR();
    public double getOverdraft();
    public void makeTransaction(Transaction t);
    public String getNumber();
    public String toString();

}