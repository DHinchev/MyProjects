package csc2022.team6.lloydsbanking;

import android.app.Activity;
import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.support.v4.widget.DrawerLayout;


public class NavMenu extends ActionBarActivity implements NavigationDrawerFragment.NavigationDrawerCallbacks {

    private NavigationDrawerFragment mNavigationDrawerFragment;
    String mTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(  R.layout.activity_nav_menu );

        mNavigationDrawerFragment = (NavigationDrawerFragment) getSupportFragmentManager().findFragmentById(R.id.navigation_drawer);
        mTitle = "Account Summary";

        mNavigationDrawerFragment.setUp( R.id.navigation_drawer,(DrawerLayout) findViewById(R.id.drawer_layout) );


        Bundle b = getIntent().getExtras();
        String userID = b.getString("userID");
        User mainUser = new User(userID);
        System.out.println( "!!!!!!!!"+ mainUser.getID()+ "!!!!!!!!!!!!" );
    }

    @Override
    public void onNavigationDrawerItemSelected(int position) {

        switch ( position ){
            case 0:
                accSummary();
                break;
            case 1:
                addressBook();
                break;
            case 2:
                guide();
                break;
            case 3:
                offers();
                break;
            case 4:
                support();
                break;
            case 5:
                logout();
                break;
        }
    }

    public void accSummary(){
        mTitle = getString( R.string.title_section1 );
        getSupportFragmentManager().beginTransaction().add( R.id.container, new Summary() ).commit();
    }

    public void addressBook(){
        mTitle = getString( R.string.title_section2 );
        getSupportFragmentManager().beginTransaction().add( R.id.container, new AddressBook() ).commit();
    }

    public void guide(){
        mTitle = getString( R.string.title_section3 );
        getSupportFragmentManager().beginTransaction().add( R.id.container, new Guide() ).commit();
    }

    public void offers(){
        mTitle = getString( R.string.title_section4 );
        getSupportFragmentManager().beginTransaction().add( R.id.container, new Offers() ).commit();
    }

    public void support(){
        mTitle = getString( R.string.title_section5 );
        getSupportFragmentManager().beginTransaction().add( R.id.container, new Support() ).commit();
    }

    public void logout(){

        finish();
        startActivity( new Intent( NavMenu.this, LoginActivity.class ) );
    }

    public void restoreActionBar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setTitle(mTitle);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (!mNavigationDrawerFragment.isDrawerOpen()) {
            getMenuInflater().inflate(R.menu.nav_menu, menu);
            restoreActionBar();
            return true;
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    public static class PlaceholderFragment extends Fragment {

        private static final String ARG_SECTION_NUMBER = "section_number";

        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        public PlaceholderFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_nav_menu, container, false);
            return rootView;
        }

        @Override
        public void onAttach(Activity activity) {
            super.onAttach(activity);
        }
    }

    @Override
    public void onBackPressed() {
    }
}
