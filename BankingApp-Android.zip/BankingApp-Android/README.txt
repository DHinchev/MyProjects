This is a team project.The team consisted of 6 people.I was responsible for the front end of the application. Everything in folder "res" where the layers, drawables and icons are located are made by me plus the java classes supporting their front-end functionality:
-LoginActivity class
-Support class
-Offer class
-NavMenu
-NavigationDrawerFragment class (only partially written by me)
-Guid class
-AddPerson class

Unfortunatellt the database provider was supporting till the begining of this year (2016) and thus you can't log in or view the pages from virtual or non-virtual android device. 
You are free to have a look at the code though.
The back end of this application was not made by me.Only the front end!The application was tested and it runs. If the application require new versions please update.My Current Gradle classpath is 1.5 - classpath 'com.android.tools.build:gradle:1.5.0'

Additional gradle ajustments you might need to run it without errors(at least in my case)-
change in gradle.properties the "distributionUrl:
 distributionUrl=https\://services.gradle.org/distributions/gradle-2.8-all.zip